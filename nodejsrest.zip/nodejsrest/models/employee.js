var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var EmployeeSchema = new Schema({
    name: {type: String, required: true, max: 100},
    pass: {type: string, required: true},
    email: {type: string, required: true},
    address: {type: string, required: true},
});


// Export the model
module.exports = mongoose.model('Employee', EmployeeSchema);