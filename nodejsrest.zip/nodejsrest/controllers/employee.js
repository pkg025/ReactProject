var Employee = require('../models/employee');

//Simple version, without validation or sanitation
exports.test = function (req, res) {
    res.send('Greetings from the Test controller!');
};

exports.employee_create = function (req, res) {
    var employee = new Employee(
        {
            name: req.body.name,
            pass: req.body.pass,
            email: req.body.email,
            address: req.body.address
        }
    );

    employee.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('Employee Created successfully')
    })
};

exports.employee_details = function (req, res) {
    Employee.findById(req.params.id, function (err, employee) {
        if (err) return next(err);
        res.send(employee);
    })
};

exports.employee_update = function (req, res) {
    Employee.findByIdAndUpdate(req.params.id, {$set: req.body}, function (err, employee) {
        if (err) return next(err);
        res.send('Employee udpated.');
    });
};

exports.employee_delete = function (req, res) {
    Employee.findByIdAndRemove(req.params.id, function (err) {
        if (err) return next(err);
        res.send('Deleted successfully!');
    })
};