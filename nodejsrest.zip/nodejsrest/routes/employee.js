var express = require('express');
var router = express.Router();

// Require the controllers WHICH WE DID NOT CREATE YET!!
var employee_controller = require('../controllers/employee');


// a simple test url to check that all of our files are communicating correctly.
router.get('/test', employee_controller.test);


router.post('/create', employee_controller.employee_create);

router.get('/:id', employee_controller.employee_details);

router.put('/:id/update', employee_controller.employee_update);

router.delete('/:id/delete', employee_controller.employee_delete);


module.exports = router;